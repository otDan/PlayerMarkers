﻿<p align="right"> 
<a href="https://www.paypal.com/paypalme/otdan">
<img src="https://raw.githubusercontent.com/aha999/DonateButtons/master/Paypal.png" height="65" />
</a>
</p>
‎<p align="center"> 
<img src="https://github.com/otDan/PlayerMarkers/blob/master/PlayerMarkers/icon-full.png?raw=true" height="275" />
</p>

## Versions
- 1.0.0
  - Initial release, no options just a marker above your player